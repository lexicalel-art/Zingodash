#!/bin/bash

# Determine the script's directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

source "$SCRIPT_DIR/utils.sh"

 # Hardcoded remote server ports
 declare -A SERVICE_TO_REMOTE_PORTS=(
     ["dashboard"]=8081
     ["db"]=8082
     )

# Load default configurations
if [ -f "$SCRIPT_DIR/env.defaults" ]; then
  source "$SCRIPT_DIR/env.defaults"
fi

# Load user-specific configurations if present
if [ -f "$SCRIPT_DIR/env.overrides" ]; then
  source "$SCRIPT_DIR/env.overrides"
fi

# Function to start port forwarding
forward_up() {
    print_blue "Starting forwarding. Checking for existing service ports."

    if [ -f /tmp/forwarder_pids ]; then
        declare -A current_forwards
        while IFS=',' read -r svc pid; do
            current_forwards[$svc]=$pid
        done < /tmp/forwarder_pids
    fi

    for service in "${!SERVICE_TO_REMOTE_PORTS[@]}"; do
        remote_port=${SERVICE_TO_REMOTE_PORTS[$service]}
        local_var="${service^^}_LOCAL_PORT"
        local_port=${!local_var}

        if [ -z "$local_port" ]; then
            print_yellow "No local port defined for $service. Skipping."
            continue
        fi

        if [[ -n "${current_forwards[$service]}" ]]; then
            print_yellow "Forwarding for $service is already active. Skipping."
            continue
        fi

        print_green "Forwarding $service (remote port $remote_port) to local port $local_port"

        # Establish SSH tunnel
        ssh -N -L ${local_port}:localhost:${remote_port} ${SERVER_USER}@${SERVER_HOST} &
        pid=$!
                                                                                                                                     
        # Store service and PID in a file
        echo "$service,$pid" >> /tmp/forwarder_pids
    done
}

# Function to stop port forwarding
forward_down() {
    if [ -f /tmp/forwarder_pids ]; then
        while IFS=',' read -r service pid; do
            kill $pid 2>/dev/null && print_green "Stopped forwarding for $service." || print_red "Failed to stop forwarding for $service."
        done < /tmp/forwarder_pids

        # Clear the file after stopping all services
        > /tmp/forwarder_pids
        echo "All forwarding services have been stopped."
    else
        echo "No forwarding services are currently running."
    fi
}

 case "$1" in
     up)
         forward_up
         ;;
     down)
         forward_down
         ;;
     *)
         echo "Usage: $0 {up|down}"
         exit 1
         ;;
 esac

