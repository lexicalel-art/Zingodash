#!/bin/bash

# Get the directory of the current script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$SCRIPT_DIR/.."

# Branch to monitor
BRANCH="master"

# Move to the repository directory
cd "$REPO_DIR" || exit

# Fetch the latest changes
git fetch origin

# Check for new commits
if [[ $(git rev-parse HEAD) != $(git rev-parse origin/$BRANCH) ]]; then
  # There are new commits
  git pull origin $BRANCH

  # Bring down current Docker containers
  docker-compose down

  # Bring up updated Docker containers
  docker-compose up -d
fi
