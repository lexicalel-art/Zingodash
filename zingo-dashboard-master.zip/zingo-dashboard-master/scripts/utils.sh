#!/bin/bash

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print a message in red
print_red() {
    echo -e "${RED}$1${NC}"
}

# Function to print a message in green
print_green() {
    echo -e "${GREEN}$1${NC}"
}

# Function to print a message in yellow
print_yellow() {
    echo -e "${YELLOW}$1${NC}"
}

# Function to print a message in blue
print_blue() {
    echo -e "${BLUE}$1${NC}"
}
