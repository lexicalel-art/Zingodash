# Zingo Dashboard Port Forwarding Script
                                                                                                                                                              
## Setup
                                                                                                                                                              
1. Clone the repository:
                                                                                                                                                              
   ```bash
   git clone https://github.com/your-username/your-repo.git
   ```
                                                                                                                                                              
2. Navigate to the root of the cloned repository directory.
                                                                                                                                                              
3. (Optional) If you need to override the default port settings provided in `env.defaults`, create an `env.overrides` file in the repo's directory:
                                                                                                                                                              
   ```bash
   touch your-repo/env.overrides
   # Edit this file to customize your local port configuration. For example:
   # DASHBOARD_LOCAL_PORT=4321
   # DB_LOCAL_PORT=8765
   ```
                                                                                                                                                              
4. Run the following command from the root of the cloned repository to add an alias for `zingo-dashboard` in your `.bashrc` (or equivalent shell configuration file). This will automatically use the current directory path:
                                                                                                                                                              
   ```bash
   echo "alias zingo-dashboard='bash $(pwd)/scripts/forwarder.sh'" >> ~/.bashrc
   ```
                                                                                                                                                              
5. Reload your `.bashrc` to apply the changes:
                                                                                                                                                              
   ```bash
   source ~/.bashrc
   ```
                                                                                                                                                              
## Usage
                                                                                                                                                              
- To start port forwarding with the Zingo Dashboard, run:
                                                                                                                                                              
  ```bash
  zingo-dashboard up
  ```
                                                                                                                                                              
- To stop all port forwarding sessions, run:
                                                                                                                                                              
  ```bash
  zingo-dashboard down
  ```
                                                                                                                                                              
## Configuration Files
                                                                                                                                                              
- **env.defaults**: Contains default server configurations and port settings for services.
- **env.overrides**: Place your custom port mappings here to override defaults. This file is ignored by Git to allow personal configurations.
