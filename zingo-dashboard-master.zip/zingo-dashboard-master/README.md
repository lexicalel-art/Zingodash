# Zingo Dashboard

This dashboard came to be as a solution to our issue with forgotten meetings, missing urls and general lack of organisation with stuff being tossed around on chats.
The idea is to host it on a server and have people access it through ssh port forwarding.

## Features

- **Meeting Times**: Easily keep track of scheduled meetings and static URLs for join links.
- **Relevant Bookmarks**: Quickly access important documents like grant specifications and relevant URLs.
- **Time Panel**: View each member's timezone to better coordinate and be aware of global participation.
- **Project-Specific Content**:
  - Repository digests
  - Release notes
  - Project bookmarks
- **General Information**: Incorporates RSS feeds and personalized content recommendations.
                                                                                                                                                                                             
## Technology
                                                                                                                                                                                             
This dashboard is built using [Glance](https://github.com/glanceapp/glance)'s Docker image and includes only two essential files:
- `config/glance.yml`: Configuration file specifying the dashboard settings.
- `compose.yml`: Docker Compose file used for setting up the environment.
                                                                                                                                                                                             
## Getting Started
                                                                                                                                                                                             
To try out the dashboard locally, follow these steps:
1. Clone the repository to your local machine.
2. Change into the repository directory:
   ```bash
   cd zingo-dashboard
   ```
3. Run the dashboard using Docker Compose:
   ```bash
   docker compose up
   ```
4. Open your browser and view the dashboard at `localhost:8081`.
                                                                                                                                                                                             
## Customization
                                                                                                                                                                                             
Feel free to modify the configuration file (`config/glance.yml`) while the Docker container is running. After making changes, simply reload the dashboard in your browser to see updates.

You can find an extensive list of out-of-the box components [here](https://github.com/glanceapp/glance/blob/main/docs/configuration.md#configuring-glance)                                                                                                                                                                                             

